SCORSTATS <-
function(){
  print(data.binary$table.stats)
  }
