SCORTECH <-
function(){
  print(data.binary$table.tech)
  }
