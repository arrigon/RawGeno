DELETOP <-
function(x){
  assign("toimport",toimport[-(x+1)],env=.GlobalEnv)
  }
