##### RawGeno V.2.0-1 Quick Readme
# New features:
- The bin editing GUI has been debugged and enhanced.
  Now you can see several electropherograms at a same time,
  and more importantly, you can save / load your preferred bin limits;
  which makes possible to score distinct datasets using the same binset.

##### Installing
From now on, RawGeno will be delivered as a source code, and not as a precompiled package
This makes more easy to install on any platform, especially because no external language is involved.
As a consequence, the installation procedure differs slightly from what is written in the manual;
but this should as simple, if not more.

### To install RawGeno from the source file (this version runs with R2.14):
# 0. Start R from where you have downloaded RawGeno

### Use the following command lines into the R console:
# 1. make sure that the working directory of R is where you have downloaded RawGeno
setwd("MyPathToRawGeno_InstallFile")

# 2. Install the package using the following command:
install.packages("RawGeno_2.0-1.tar.gz", repos = NULL, type = "source")
install.packages("vegan") # optional, but will let you explore your results with the PCoA display.
install.packages("tkrplot") # optional, but RawGeno will kindly recall you that you should install it to benefit from all the available options ;)

# 3. load the package and have fun!
require(RawGeno)
require(vegan)
RawGeno()


#### The tkrplot fun part for Linux users...
Linux users; if you have troubles for installing tkrplot,
note that precompiled versions are available in the usual Ubuntu directories.

If you still experience troubles, make sure that you have the following libraries already installed:
libx11-dev
tcl8.5-dev
tk8.5-dev

and retry to install it. This solved my issues actually.

